import pygame

class GameController:
    def handle_events(self, model, view):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                model.running = False

            elif event.type == pygame.VIDEORESIZE and not view.fullscreen:
                view.resize_window(event.w, event.h)

            elif event.type == pygame.KEYDOWN:
                # F11 toggles fullscreen in every game state.
                if event.key == pygame.K_F11:
                    view.toggle_fullscreen()
                    continue

                if model.state == "menu":
                    if event.key == pygame.K_RETURN:
                        model.reset()
                        model.state = "playing"
                    elif event.key == pygame.K_ESCAPE:
                        model.running = False

                elif model.state == "playing":
                    if event.key == pygame.K_ESCAPE:
                        model.state = "menu"

                    elif model.turn == "player" and not model.projectile and not model.explosion:
                        if event.key == pygame.K_LEFT:
                            model.adjust_aim(angle_change=2)
                        elif event.key == pygame.K_RIGHT:
                            model.adjust_aim(angle_change=-2)
                        elif event.key == pygame.K_UP:
                            model.adjust_aim(power_change=3)
                        elif event.key == pygame.K_DOWN:
                            model.adjust_aim(power_change=-3)
                        elif event.key == pygame.K_SPACE:
                            model.fire(model.player)

                elif model.state in ("victory", "game_over"):
                    if event.key == pygame.K_RETURN:
                        model.reset()
                        model.state = "playing"
                    elif event.key == pygame.K_ESCAPE:
                        model.state = "menu"

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if model.state == "menu":
                    logical_pos = view.window_to_logical(event.pos)
                    if view.fullscreen_button_rect.collidepoint(logical_pos):
                        view.toggle_fullscreen()