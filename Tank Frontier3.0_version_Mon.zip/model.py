import math
import random


class Tank:
    def __init__(self, x, color, name, direction):
        self.x = float(x)
        self.color = color
        self.name = name
        self.direction = direction  # 1 = right, -1 = left
        self.hp = 100
        self.max_hp = 100
        self.angle = 45.0
        self.power = 70.0

    def alive(self):
        return self.hp > 0


class GameModel:
    WIDTH = 1000
    HEIGHT = 600
    GROUND_BASE = 430

    def __init__(self):
        self.reset()

    def reset(self):
        self.running = True
        self.state = "menu"
        self.turn = "player"
        self.score = 0
        self.message = "Your turn"
        self.projectile = None
        self.explosion = None
        self.enemy_wait = 0.0

        self.player = Tank(105, (62, 112, 55), "PLAYER", 1)
        self.enemy = Tank(895, (115, 121, 128), "ENEMY AI", -1)

        # One fixed map. Each entry is the ground height at that x-column.
        self.terrain = []
        for x in range(self.WIDTH + 1):
            y = (self.GROUND_BASE
                 + 22 * math.sin(x * 0.012)
                 + 13 * math.sin(x * 0.027 + 1.4)
                 + 7 * math.sin(x * 0.052))
            self.terrain.append(int(y))

        self.trees = [
            {"x": 270, "hp": 35, "max_hp": 35, "alive": True},
            {"x": 610, "hp": 35, "max_hp": 35, "alive": True},
            {"x": 760, "hp": 35, "max_hp": 35, "alive": True},
        ]
        self.rocks = [
            {"x": 405, "w": 42, "h": 25, "hp": 55, "max_hp": 55, "alive": True},
            {"x": 520, "w": 66, "h": 38, "hp": 75, "max_hp": 75, "alive": True},
            {"x": 825, "w": 50, "h": 30, "hp": 60, "max_hp": 60, "alive": True},
        ]

    def ground_y(self, x):
        x = max(0, min(self.WIDTH, int(x)))
        return self.terrain[x]

    def tank_ground_y(self, tank):
        return self.ground_y(tank.x)

    def adjust_aim(self, angle_change=0, power_change=0):
        if self.state != "playing" or self.turn != "player" or self.projectile:
            return
        self.player.angle = max(10, min(80, self.player.angle + angle_change))
        self.player.power = max(35, min(100, self.player.power + power_change))

    def fire(self, tank):
        if self.state != "playing" or self.projectile or self.explosion:
            return
        if tank is self.player and self.turn != "player":
            return
        if tank is self.enemy and self.turn != "enemy":
            return

        angle = math.radians(tank.angle)
        direction = tank.direction
        base_y = self.tank_ground_y(tank) - 20
        start_x = tank.x + direction * 27
        start_y = base_y - math.sin(angle) * 25
        speed = tank.power * (6.2 if tank is self.player else 5.0)  # Player range boost.
        self.projectile = {
            "x": start_x,
            "y": start_y,
            "vx": direction * math.cos(angle) * speed,
            "vy": -math.sin(angle) * speed * 0.80,
            "owner": tank.name,
        }
        self.message = f"{tank.name} fired!"

    def update_projectile(self, dt):
        if not self.projectile:
            return

        p = self.projectile
        p["x"] += p["vx"] * dt
        p["y"] += p["vy"] * dt
        p["vy"] += 260 * dt  # Tuned for arcade-style screen motion.

        x = int(p["x"])
        y = int(p["y"])

        if x < 0 or x >= self.WIDTH or y > self.HEIGHT:
            self.create_explosion(max(0, min(self.WIDTH, x)), max(0, min(self.HEIGHT, y)))
            return

        # Tank collision.
        target = self.enemy if p["owner"] == "PLAYER" else self.player
        tank_center_y = self.tank_ground_y(target) - 17
        if math.hypot(p["x"] - target.x, p["y"] - tank_center_y) < 25:
            self.create_explosion(p["x"], p["y"])
            return

        # Rock collision.
        for rock in self.rocks:
            if rock["alive"]:
                rx = rock["x"]
                ry = self.ground_y(rx) - rock["h"] / 2
                if abs(p["x"] - rx) < rock["w"] / 2 and abs(p["y"] - ry) < rock["h"] / 2 + 5:
                    self.create_explosion(p["x"], p["y"])
                    return

        # Tree collision.
        for tree in self.trees:
            if tree["alive"]:
                tx = tree["x"]
                ty = self.ground_y(tx)
                if abs(p["x"] - tx) < 17 and ty - 65 < p["y"] < ty:
                    self.create_explosion(p["x"], p["y"])
                    return

        # Ground collision.
        if p["y"] >= self.ground_y(x):
            self.create_explosion(p["x"], self.ground_y(x))

    def create_explosion(self, x, y):
        if not self.projectile:
            return
        owner = self.projectile["owner"]
        self.projectile = None
        self.explosion = {"x": float(x), "y": float(y), "time": 0.0, "duration": 0.55, "radius": 76}
        self.apply_explosion_damage(float(x), float(y), owner)

    def apply_explosion_damage(self, x, y, owner):
        radius = 76
        max_damage = 42

        target = self.enemy if owner == "PLAYER" else self.player
        target_x = target.x
        target_y = self.tank_ground_y(target) - 17
        distance = math.hypot(target_x - x, target_y - y)

        if distance < radius:
            damage = max(1, int(max_damage * (1 - distance / radius)))
            target.hp = max(0, target.hp - damage)
            if owner == "PLAYER":
                self.score += damage * 10
            self.message = f"{target.name} took {damage} damage!"

        for tree in self.trees:
            if tree["alive"] and abs(tree["x"] - x) < radius:
                damage = max(1, int(35 * (1 - abs(tree["x"] - x) / radius)))
                tree["hp"] -= damage
                if tree["hp"] <= 0:
                    tree["alive"] = False
                    if owner == "PLAYER":
                        self.score += 100

        for rock in self.rocks:
            if rock["alive"] and abs(rock["x"] - x) < radius:
                damage = max(1, int(45 * (1 - abs(rock["x"] - x) / radius)))
                rock["hp"] -= damage
                if rock["hp"] <= 0:
                    rock["alive"] = False
                    if owner == "PLAYER":
                        self.score += 150

        # Make a visible crater in the terrain.
        crater_radius = 48
        center = max(0, min(self.WIDTH, int(x)))
        for column in range(max(0, center - crater_radius), min(self.WIDTH, center + crater_radius) + 1):
            distance = abs(column - center)
            depth = int(34 * (1 - distance / crater_radius))
            self.terrain[column] = min(self.HEIGHT - 35, self.terrain[column] + depth)

    def update(self, dt):
        if self.state != "playing":
            return

        if self.projectile:
            self.update_projectile(dt)

        if self.explosion:
            self.explosion["time"] += dt
            if self.explosion["time"] >= self.explosion["duration"]:
                self.explosion = None
                self.finish_turn()

        if self.turn == "enemy" and not self.projectile and not self.explosion:
            self.enemy_wait += dt
            if self.enemy_wait >= 0.8:
                self.choose_enemy_aim()
                self.fire(self.enemy)
                self.enemy_wait = 0.0

    def finish_turn(self):
        if self.enemy.hp <= 0:
            self.state = "victory"
            self.message = "Victory! Enemy tank defeated."
        elif self.player.hp <= 0:
            self.state = "game_over"
            self.message = "Game Over! Your tank was defeated."
        else:
            self.turn = "enemy" if self.turn == "player" else "player"
            self.enemy_wait = 0.0
            self.message = "Your turn" if self.turn == "player" else "Enemy is aiming..."

    def choose_enemy_aim(self):
        # Random arcade accuracy level each turn: easier and less predictable.
        hit_chance = random.choice([5, 10, 15, 20])

        best_choice = (45, 70)
        best_distance = float("inf")

        # Find a baseline shot, then deliberately randomize the result.
        for angle in range(15, 81, 3):
            for power in range(45, 101, 5):
                landing = self.predict_enemy_landing(angle, power)
                distance = abs(landing - self.player.x)
                if distance < best_distance:
                    best_distance = distance
                    best_choice = (angle, power)

        if random.randint(1, 100) <= hit_chance:
            angle = best_choice[0] + random.randint(-3, 3)
            power = best_choice[1] + random.randint(-5, 5)
        else:
            angle = best_choice[0] + random.choice([-1, 1]) * random.randint(9, 24)
            power = best_choice[1] + random.choice([-1, 1]) * random.randint(12, 28)

        self.enemy.angle = max(15, min(80, angle))
        self.enemy.power = max(45, min(100, power))

    def predict_enemy_landing(self, angle_degrees, power):
        angle = math.radians(angle_degrees)
        speed = power * 5.0
        vx = -math.cos(angle) * speed
        vy = -math.sin(angle) * speed * 0.80
        x = self.enemy.x - 27
        y = self.tank_ground_y(self.enemy) - 40
        step = 0.035

        for _ in range(180):
            x += vx * step
            y += vy * step
            vy += 260 * step

            if x <= 0:
                return 0
            if x >= self.WIDTH:
                return self.WIDTH
            if y >= self.ground_y(x):
                return x

            for rock in self.rocks:
                if rock["alive"] and abs(x - rock["x"]) < rock["w"] / 2:
                    rock_y = self.ground_y(rock["x"]) - rock["h"] / 2
                    if abs(y - rock_y) < rock["h"] / 2 + 5:
                        return x

            for tree in self.trees:
                if tree["alive"] and abs(x - tree["x"]) < 17:
                    if self.ground_y(tree["x"]) - 65 < y < self.ground_y(tree["x"]):
                        return x

        return x