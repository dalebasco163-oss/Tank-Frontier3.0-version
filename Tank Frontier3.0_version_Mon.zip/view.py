import math
import pygame


class GameView:
    SKY = (160, 180, 205)
    GROUND = (20, 105, 25)

    def __init__(self):
        self.width = 1000
        self.height = 600
        # Draw everything on a fixed-size logical canvas. It is scaled to the
        # actual display while preserving the original 1000:600 aspect ratio.
        self.screen = pygame.Surface((self.width, self.height))
        self.fullscreen = False
        self.window_size = (self.width, self.height)
        self.display = pygame.display.set_mode(self.window_size, pygame.RESIZABLE)
        pygame.display.set_caption("Tank Frontier")
        self.clock = pygame.time.Clock()
        self.fullscreen_button_rect = pygame.Rect(30, 30, 205, 48)
        self.font = pygame.font.SysFont("arial", 22, bold=True)
        self.small_font = pygame.font.SysFont("arial", 16)
        self.big_font = pygame.font.SysFont("arial", 48, bold=True)
        self.clouds = [[100.0, 90.0, 1.0], [400.0, 130.0, 0.7], [750.0, 75.0, 1.2]]
        # Each sky phase lasts 80 seconds (1 minute 20 seconds).
        self.day_elapsed = 0.0
        self.phase_duration = 80.0
        self.stars = [
            (75, 85), (155, 145), (245, 65), (335, 115), (455, 70),
            (565, 130), (680, 75), (790, 145), (900, 80), (950, 190),
            (380, 205), (620, 225), (845, 250), (115, 260)
        ]

    def resize_window(self, width, height):
        width = max(400, width)
        height = max(240, height)
        self.window_size = (width, height)
        self.display = pygame.display.set_mode(self.window_size, pygame.RESIZABLE)

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        if self.fullscreen:
            self.display = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.display = pygame.display.set_mode(self.window_size, pygame.RESIZABLE)

    def window_to_logical(self, position):
        display_width, display_height = self.display.get_size()
        scale = min(display_width / self.width, display_height / self.height)
        rendered_width = self.width * scale
        rendered_height = self.height * scale
        offset_x = (display_width - rendered_width) / 2
        offset_y = (display_height - rendered_height) / 2
        x = (position[0] - offset_x) / scale
        y = (position[1] - offset_y) / scale
        return int(x), int(y)

    def present(self):
        display_width, display_height = self.display.get_size()
        scale = min(display_width / self.width, display_height / self.height)
        rendered_width = max(1, int(self.width * scale))
        rendered_height = max(1, int(self.height * scale))
        scaled = pygame.transform.smoothscale(self.screen, (rendered_width, rendered_height))
        self.display.fill((0, 0, 0))
        offset_x = (display_width - rendered_width) // 2
        offset_y = (display_height - rendered_height) // 2
        self.display.blit(scaled, (offset_x, offset_y))
        pygame.display.flip()

    def update(self, dt):
        self.day_elapsed += dt
        for cloud in self.clouds:
            cloud[0] += cloud[2] * 22 * dt
            if cloud[0] > self.width + 65:
                cloud[0] = -65

    def draw_cloud(self, x, y):
        phase_index = int((self.day_elapsed / self.phase_duration) % 4)
        color = (185, 190, 205) if phase_index == 3 else (248, 250, 255)
        pygame.draw.circle(self.screen, color, (int(x), int(y)), 21)
        pygame.draw.circle(self.screen, color, (int(x + 24), int(y - 10)), 27)
        pygame.draw.circle(self.screen, color, (int(x + 49), int(y)), 21)
        pygame.draw.rect(self.screen, color, (int(x), int(y - 4), 50, 23))

    def get_sky_color(self):
        # Sunrise -> Noon -> Sunset -> Night; each phase lasts 80 seconds.
        colors = [
            (238, 151, 105),  # Sunrise
            (135, 185, 230),  # Noon
            (226, 119, 88),   # Sunset
            (15, 24, 49),     # Night
        ]
        position = (self.day_elapsed / self.phase_duration) % 4
        index = int(position)
        blend = position - index
        start = colors[index]
        end = colors[(index + 1) % 4]
        return tuple(int(start[i] + (end[i] - start[i]) * blend) for i in range(3))

    def draw_sky_objects(self):
        position = (self.day_elapsed / self.phase_duration) % 4
        index = int(position)
        progress = position - index

        if index == 3:
            for sx, sy in self.stars:
                pygame.draw.circle(self.screen, (245, 245, 220), (sx, sy), 2)
            pygame.draw.circle(self.screen, (238, 238, 210), (830, 105), 29)
            pygame.draw.circle(self.screen, self.get_sky_color(), (842, 94), 26)
        else:
            if index == 0:
                sun_x = int(100 + progress * 350)
                sun_y = int(390 - progress * 280)
            elif index == 1:
                sun_x = int(450 + progress * 250)
                sun_y = int(110 + progress * 35)
            else:
                sun_x = int(700 + progress * 220)
                sun_y = int(145 + progress * 260)
            pygame.draw.circle(self.screen, (255, 218, 115), (sun_x, sun_y), 27)

    def draw_battlefield(self, model):
        self.screen.fill(self.get_sky_color())
        self.draw_sky_objects()

        for cloud in self.clouds:
            self.draw_cloud(cloud[0], cloud[1])

        ground_points = [(x, y) for x, y in enumerate(model.terrain)]
        ground_points += [(self.width, self.height), (0, self.height)]
        pygame.draw.polygon(self.screen, self.GROUND, ground_points)

        # Trees
        for tree in model.trees:
            if tree["alive"]:
                x = tree["x"]
                y = model.ground_y(x)
                pygame.draw.rect(self.screen, (105, 65, 30), (x - 6, y - 34, 12, 34))
                pygame.draw.circle(self.screen, (12, 82, 24), (x, y - 48), 24)
                pygame.draw.circle(self.screen, (25, 125, 35), (x - 14, y - 39), 17)
                pygame.draw.circle(self.screen, (25, 125, 35), (x + 14, y - 39), 17)

        # Rocks
        for rock in model.rocks:
            if rock["alive"]:
                x = rock["x"]
                y = model.ground_y(x)
                rect = pygame.Rect(x - rock["w"] // 2, y - rock["h"], rock["w"], rock["h"])
                pygame.draw.ellipse(self.screen, (100, 101, 108), rect)
                pygame.draw.ellipse(self.screen, (130, 131, 137),
                                    (rect.x + 7, rect.y + 4, max(8, rect.w // 2), max(6, rect.h // 2)))

    def draw_tank(self, model, tank):
        ground = model.tank_ground_y(tank)
        x = int(tank.x)
        body_color = tank.color

        # Tracks
        pygame.draw.ellipse(self.screen, (38, 40, 38), (x - 31, ground - 20, 62, 19))
        pygame.draw.ellipse(self.screen, (95, 98, 88), (x - 25, ground - 17, 50, 12))

        # Tank body and turret
        pygame.draw.rect(self.screen, body_color, (x - 27, ground - 34, 54, 19), border_radius=5)
        pygame.draw.circle(self.screen, body_color, (x, ground - 35), 13)

        # Barrel follows the selected angle.
        angle = math.radians(tank.angle)
        end_x = x + tank.direction * math.cos(angle) * 42
        end_y = ground - 35 - math.sin(angle) * 42
        pygame.draw.line(self.screen, (45, 48, 43), (x, ground - 35),
                         (int(end_x), int(end_y)), 8)
        pygame.draw.line(self.screen, body_color, (x, ground - 35),
                         (int(end_x), int(end_y)), 5)

    def draw_health_bar(self, x, y, tank):
        label = self.small_font.render(f"{tank.name}  {tank.hp}/100 HP", True, (255, 255, 255))
        self.screen.blit(label, (x, y))
        bar = pygame.Rect(x, y + 23, 220, 16)
        pygame.draw.rect(self.screen, (45, 45, 45), bar, border_radius=5)
        fill_width = int(220 * max(0, tank.hp) / tank.max_hp)
        fill_color = (45, 190, 85) if tank.hp > 35 else (210, 65, 55)
        if fill_width > 0:
            pygame.draw.rect(self.screen, fill_color,
                             (bar.x, bar.y, fill_width, bar.height), border_radius=5)

    def draw_explosion(self, explosion):
        progress = explosion["time"] / explosion["duration"]
        radius = int(12 + 55 * min(1, progress))
        center = (int(explosion["x"]), int(explosion["y"]))
        pygame.draw.circle(self.screen, (235, 90, 25), center, radius)
        pygame.draw.circle(self.screen, (255, 185, 45), center, int(radius * 0.70))
        pygame.draw.circle(self.screen, (255, 235, 150), center, int(radius * 0.36))

    def draw_hud(self, model):
        self.draw_health_bar(25, 18, model.player)
        self.draw_health_bar(755, 18, model.enemy)

        turn_text = self.font.render(model.message, True, (255, 255, 255))
        self.screen.blit(turn_text, (self.width // 2 - turn_text.get_width() // 2, 18))

        score = self.small_font.render(f"Score: {model.score}", True, (255, 255, 255))
        self.screen.blit(score, (25, 70))

        if model.turn == "player" and model.state == "playing":
            controls = f"ANGLE: {model.player.angle:.0f}°   POWER: {model.player.power:.0f}"
            aim_text = self.small_font.render(controls, True, (255, 255, 255))
            self.screen.blit(aim_text, (25, 95))
            help_text = self.small_font.render("LEFT/RIGHT: angle   UP/DOWN: power   SPACE: fire", True, (255, 255, 255))
            self.screen.blit(help_text, (25, 565))

    def draw_menu(self):
        self.screen.fill(self.SKY)

        # Fullscreen toggle button on the left side of the main menu.
        button_color = (35, 75, 48) if not self.fullscreen else (55, 95, 125)
        pygame.draw.rect(self.screen, button_color, self.fullscreen_button_rect, border_radius=9)
        pygame.draw.rect(self.screen, (235, 240, 235), self.fullscreen_button_rect, 2, border_radius=9)
        button_label = "FULLSCREEN: ON" if self.fullscreen else "FULLSCREEN: OFF"
        button_text = self.small_font.render(button_label, True, (255, 255, 255))
        self.screen.blit(button_text, (self.fullscreen_button_rect.centerx - button_text.get_width() // 2,
                                       self.fullscreen_button_rect.centery - button_text.get_height() // 2))

        title = self.big_font.render("TANK FRONTIER", True, (35, 55, 42))
        subtitle = self.font.render("A Turn-Based Tank Artillery Game", True, (35, 55, 42))
        start = self.font.render("PRESS ENTER TO START", True, (255, 255, 255))
        quit_text = self.small_font.render("ESC TO QUIT", True, (255, 255, 255))
        self.screen.blit(title, (self.width // 2 - title.get_width() // 2, 190))
        self.screen.blit(subtitle, (self.width // 2 - subtitle.get_width() // 2, 255))
        self.screen.blit(start, (self.width // 2 - start.get_width() // 2, 335))
        self.screen.blit(quit_text, (self.width // 2 - quit_text.get_width() // 2, 375))

    def draw_end_screen(self, model):
        overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 145))
        self.screen.blit(overlay, (0, 0))
        title_text = "VICTORY!" if model.state == "victory" else "GAME OVER"
        title = self.big_font.render(title_text, True, (255, 255, 255))
        result = self.font.render(model.message, True, (255, 255, 255))
        final_score = self.font.render(f"FINAL SCORE: {model.score}", True, (255, 225, 120))
        restart = self.font.render("PRESS ENTER TO PLAY AGAIN", True, (255, 255, 255))
        menu = self.small_font.render("ESC TO RETURN TO MENU", True, (255, 255, 255))
        self.screen.blit(title, (self.width // 2 - title.get_width() // 2, 190))
        self.screen.blit(result, (self.width // 2 - result.get_width() // 2, 250))
        self.screen.blit(final_score, (self.width // 2 - final_score.get_width() // 2, 300))
        self.screen.blit(restart, (self.width // 2 - restart.get_width() // 2, 365))
        self.screen.blit(menu, (self.width // 2 - menu.get_width() // 2, 405))

    def draw(self, model):
        if model.state == "menu":
            self.draw_menu()
        else:
            self.draw_battlefield(model)
            self.draw_tank(model, model.player)
            self.draw_tank(model, model.enemy)

            if model.projectile:
                pygame.draw.circle(self.screen, (35, 35, 35),
                                   (int(model.projectile["x"]), int(model.projectile["y"])), 6)

            if model.explosion:
                self.draw_explosion(model.explosion)

            self.draw_hud(model)

            if model.state in ("victory", "game_over"):
                self.draw_end_screen(model)

        self.present()